<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile Dashboard</title>
  <link rel="stylesheet" href="styles.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body>
<div>
    <div class="dashboard-main-cont">
          <!-- Sidebar -->
        <div class="sidebar">
            <div class="profile-section">
                <img src="images/kuromi.webp" alt="Profile Image" class="profile-img" />
                <h2 class="profile-name">Christine Anne Alesna</h2>
                <button class="logout-btn">Logout</button>
            </div>
            <div class="nav-link-container">
                <div class="nav-links">
                    <a href="#" id="Profile">Profile</a>
                    <a href="#" id="Dashboard">Announcement</a>
                    <a href="#" id="RulesAndReg">Rules & Regulation</a>
                    <a href="#" id="SitinHistory">Sit-in History</a>
                    <a href="#" id="Reservation">Reservation</a>
                </div>
            </div>
            <div class="session-info">
                <p>Remaining Session:</p>
                <p>30</p>
            </div>
        </div>

        <!-- Main Content -->
        <div id="Main-content">
            <div class="AANOUNCEMENT">
                <H1>ANNOUNCEMENT</H1>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
const originalContent = document.getElementById("Main-content").innerHTML;
const links = document.querySelectorAll(".selection");

function setActiveLink(clickedLink) {
links.forEach(link => link.classList.remove("active"));
clickedLink.classList.add("active");
}

document.getElementById("Profile").addEventListener("click", function(event) {
event.preventDefault();
fetch('Profile.php')
.then(response => response.text())
.then(data => {
document.getElementById("Main-content").innerHTML = data;
})
.catch(error => console.error('Error fetching content:', error));
});

document.getElementById("Dashboard").addEventListener("click", function(event) {
event.preventDefault();
document.getElementById("Main-content").innerHTML = originalContent;
setActiveLink(this);
});

document.getElementById("RulesAndReg").addEventListener("click", function(event) {
event.preventDefault();
fetch('RulesAndReg.php')
.then(response => response.text())
.then(data => {
document.getElementById("Main-content").innerHTML = data;
})
.catch(error => console.error('Error fetching content:', error));
});


document.getElementById("SitinHistory").addEventListener("click", function(event) {
event.preventDefault();
fetch('SitinHistory.php')
.then(response => response.text())
.then(data => {
document.getElementById("Main-content").innerHTML = data;
setActiveLink(this);
})
.catch(error => console.error('Error fetching content:', error));
});


document.getElementById("Reservation").addEventListener("click", function(event) {
event.preventDefault();
fetch('Reservation.php')
.then(response => response.text())
.then(data => {
document.getElementById("Main-content").innerHTML = data;
setActiveLink(this);
})
.catch(error => console.error('Error fetching content:', error));
});
});
</script>
</body>
</html>


