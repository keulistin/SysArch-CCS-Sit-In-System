
<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $conn = new mysqli('localhost', 'root', '', 'activities');

    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
        $hashed_password = $row['password'];

        if ($password == $hashed_password) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            echo "success";
            exit();
        } else {
            echo "Invalid username or password.";
            exit();
        }
    } else {
        echo "Invalid username or password.";
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Poppins', sans-serif;
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
            width: 70%;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-top: 10px;
            font-size: 15px;
            color:rgb(97, 97, 97);
        }
        input {
            width: 95%;
            padding: 5px;
            font-size: 20x;
            border:none;
            background-color: #d9d9d9;
            border-radius:5px;
        }
        button {
            width: 50%;
            padding: 5px;
            margin-top: 10px;
            align-self: center;
        }
        a {
            display: block;
            text-align: center;
            margin-top: 10px;
        }
        #container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 500px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background-color: white;
        }
        #buttons {
            padding-top: 10%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-bottom: 10%;
        }
        #register {
            font-size: 11px;
            text-decoration: none;
            color: grey;
        }
        #title {
            margin-bottom: 10%;
            font-size: 20px;
            font-weight: 500;
        }
        #top {
            padding-top: 5%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }
        #loginForm {
            width: 80%;
        }
        #login {
            background-color: purple;
            color: white;
            border: none;
            border-radius: 20px;
            font-size:15px;
            width: 70%;
            margin-bottom:-5px;
            padding:5px;
        }
    </style>
</head>
<body style="background-image: url('images/background.png'); background-size: cover; background-position: center;">
    <div id="container">
        <div id="top">
            <img src="images/CCS_LOGO.png" alt="Logo" width="100px" height="100px">
            <h1 id="title">CSS SIT-IN MONITORING SYSTEM</h1>
        </div>
        <form id="loginForm">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <div id="buttons">            
                <button type="submit" id="login">Login</button>
                <a id="register" href="register.php">Register</a>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault();

            var formData = new FormData(this);

            fetch('login.php', {  // Explicitly targeting login.php
                method  : 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data.trim() === 'success') {
                    window.location.href = 'dashboard.php';
                } else {
                    document.getElementById('error-message').textContent = data;
                }
            })
            .catch(error => {
                document.getElementById('error-message').textContent = "Error: " + error;
            });
        });
    </script>
</body>
</html>


