<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
</head>
<body>
    <div class="profile-main-container">
    <h1 class="title">PROFILE</h1>
            <div class="profile-details">
                <p><span>ID Number:</span> 22613871</p>
                <p><span>Last Name:</span> Alesna</p>
                <p><span>First Name:</span> Christine Anne</p>
                <p><span>Middle Initial:</span> A.</p>
                <p><span>Course:</span> BSIT</p>
                <p><span>Year Level:</span> 1</p>
                <p><span>Email Address:</span> christineannealesna@gmail.com</p>
                <p><span>Username:</span> keulistin</p>
                <p><span>Password:</span> ********</p>
                <button class="edit-btn">Edit Profile</button>
            </div>
    </div>
</body>
</html>